package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.example.demo.Entity.Continent;
import com.example.demo.repository.ContinentRepository;

@Service
public class ContinentService {
	@Autowired
	private final RestTemplate restTemplate;
	@Autowired
	private final ContinentRepository continentRepository;

	public ContinentService(RestTemplate restTemplate, ContinentRepository continentRepository) {
		this.restTemplate = restTemplate;
		this.continentRepository = continentRepository;
	}

	public void fetchAndSaveContinents() {
		String url = "https://dummy-json.mock.beeceptor.com/continents";
		Continent[] continents = restTemplate.getForObject(url, Continent[].class);
		continentRepository.saveAll(List.of(continents));

	}
}
