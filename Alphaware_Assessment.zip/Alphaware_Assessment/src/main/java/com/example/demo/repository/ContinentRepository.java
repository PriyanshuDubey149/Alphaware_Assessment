package com.example.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.Entity.Continent;

public interface ContinentRepository extends JpaRepository<Continent, Long> {

}
