package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.service.ContinentService;

@RestController
@RequestMapping("/api")
public class ContinentController {
	@Autowired
	private final ContinentService continentService;

	public ContinentController(ContinentService continentService) {
		this.continentService = continentService;
	}

	@GetMapping("/fetch-continents")
	public String fetchContinents() {
		continentService.fetchAndSaveContinents();
		return "Continents data fetched and saved successfully!";

	}
}
